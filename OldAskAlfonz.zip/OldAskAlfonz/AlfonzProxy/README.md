---
title: AlfonzProxy
emoji: 🚀
colorFrom: gray
colorTo: red
sdk: docker
app_port: 7860
pinned: false
---

Copyright © 2026 TrafkHop Entertainment™
All rights reserved.

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
